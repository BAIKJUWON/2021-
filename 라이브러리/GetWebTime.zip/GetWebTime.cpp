#include "GetWebTime.h"
#include <ESP8266WiFi.h>

const char *month_arr[13] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
const char *day_arr[7] = {"Sun", "Mon", "Tue", "Wen", "Thu", "Fri", "Sat"};
char buf[40];
char *time_cut=0;
char *time_val[8] = {0};
char DaysOfMonth[] = {31,28,31,30,31,30,31,31,30,31,30,31};

String get_date_time() {
  String str_time = getTime();
  str_time.toCharArray(buf, 30);
  
  time_cut = strtok(buf, ", :");
  
  for(int i=0; time_cut; i++){ 
    time_val[i] = time_cut; 
    time_cut = strtok(0, ", :");
  }
 
  int year   = atoi(time_val[3]);
  int month  = month_to_digit((char *)time_val[2]);
  int date   = atoi(time_val[1]);
  int day    = day_to_digit((char *)time_val[0]);
  int hour   = atoi(time_val[4]) + 9;
  int minute = atoi(time_val[5]);
  int second = atoi(time_val[6]);
 
  if(hour>23) {
    hour %=24;
    if(++day>6) day=0;
    if     (!(year%400)) DaysOfMonth[1]=29;  // 윤년/윤달 계산
    else if(!(year%100)) DaysOfMonth[1]=28; 
    else if(!(year%  4)) DaysOfMonth[1]=29;  
    
    if(date<DaysOfMonth[month-1]) date++;
    else {
      date=1;
      if(++month>12) {
        month=1;
        year++;
      }  
    }
  }
  
  // Serial.println(str_time);

  sprintf(buf, "%02d%02d", hour, minute);
  // sprintf(buf, "%04d%02d%02d%02d%02d%02d%s", year, month, date,hour, minute, second,day_arr[day]);
  // Serial.print(buf);  
  int i=0;
  String st;
  
  while(buf[i]) {
    st = st+buf[i];
    i++;
  }
  return st;
}


int month_to_digit(char* str) {
  for(int i=0; i<12; i++) {
      if(!strncmp(str, (char *)month_arr[i], 3)) return i+1;
  }
}

int day_to_digit(char* str) {
  for(int i=0; i<7; i++) {
      if(!strncmp(str, (char *)day_arr[i], 3)) return i;
  }
}

String getTime() {
  WiFiClient client;
  while (!!!client.connect("google.com", 80)) {
      Serial.println("connection failed, retrying...");
  }
 
  client.print("HEAD / HTTP/1.1\r\n\r\n");
 
  while(!!!client.available()) {
     yield();
  }
 
  while(client.available()){
    if (client.read() == '\n') {    
      if (client.read() == 'D') {    
        if (client.read() == 'a') {    
          if (client.read() == 't') {    
            if (client.read() == 'e') {    
              if (client.read() == ':') {    
                client.read();
                String theDate = client.readStringUntil('\r');
                client.stop();
                return theDate;
              }
            }
          }
        }
      }
    }
  }
}
