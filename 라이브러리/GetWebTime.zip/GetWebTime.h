#include "FirebaseESP8266.h"
#ifndef TIME_H
#define TIME_H
  
void fn1(void);
  
String get_date_time();
  
int month_to_digit(char* str);
  
int day_to_digit(char* str);
  
String getTime();
#endif
